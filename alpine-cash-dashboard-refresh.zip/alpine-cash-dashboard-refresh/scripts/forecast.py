#!/usr/bin/env python3
"""Alpine cash dashboard forecast engine.
Usage: python3 forecast.py inputs.json data.json
Reads the day's gathered inputs, builds the 13-week committed-only forecast
plus the service-work upside line, and writes the dashboard data file."""
import json, sys, datetime as dt
D = dt.date.fromisoformat

def run(inp):
    today = D(inp["asOf"])
    W0 = today - dt.timedelta(days=today.weekday())          # Monday of this week
    weeks = [W0 + dt.timedelta(7 * i) for i in range(13)]
    wk = lambda d: (lambda i: i if 0 <= i < 13 else None)((d - W0).days // 7)
    cin = {k: [0.0] * 13 for k in ["ar", "contracts", "projects"]}
    cout = {k: [0.0] * 13 for k in ["burn", "disc", "draws", "ap", "cards", "cra", "hst", "materials", "other"]}
    notes = [[] for _ in range(13)]
    def add(t, k, d, a, note=None):
        i = wk(d)
        if i is None: return
        t[k][i] += a
        if note: notes[i].append(note)

    # 1. Open invoices: expected at invoice date + customer lag; already late -> spread weeks 1-3
    for iv in inp["openInvoices"]:
        exp = D(iv["date"]) + dt.timedelta(iv.get("lagDays", inp.get("defaultLagDays", 24)))
        if exp < today:
            for k in (0, 1, 2): add(cin, "ar", weeks[k] + dt.timedelta(3), iv["amount"] / 3)
        else:
            add(cin, "ar", exp, iv["amount"], iv.get("note"))
    # 2. Other scheduled inflows (estimates to bill, one-offs)
    for s in inp.get("scheduledIn", []):
        add(cin, s.get("cat", "ar"), D(s["date"]) + dt.timedelta(s.get("lagDays", 0)), s["amount"], s.get("note"))
    # 3. Monthly contracts
    for c in inp["contracts"]:
        m = dt.date(W0.year, W0.month, 1)
        for _ in range(5):
            bill = dt.date(m.year, m.month, c.get("day", 1))
            if bill >= today - dt.timedelta(days=45) and not (c.get("skipBilledBefore") and bill <= D(c["skipBilledBefore"])):
                add(cin, "contracts", bill + dt.timedelta(c["lagDays"]), c["amount"])
            m = dt.date(m.year + (m.month // 12), m.month % 12 + 1, 1)
    # 4. Jobs: remaining billings + materials
    table = []
    for j in inp["jobs"]:
        for e in j.get("events", []):
            add(cin, "projects", D(e["date"]) + dt.timedelta(e.get("lagDays", 30)), e["amount"],
                f'{j["name"]} {e.get("label","")} collected (${e["amount"]/1000:.1f}K)' if e["amount"] > 20000 else None)
        for mt in j.get("materials", []):
            add(cout, "materials", D(mt["date"]), mt["amount"],
                f'{j["name"]} materials paid (${mt["amount"]/1000:.1f}K)' if mt["amount"] > 30000 else None)
        ev = j.get("events", [])
        table.append(dict(name=j["name"], job=j.get("job", "—"), po=j.get("po", "—"), quoted=j["quoted"],
                          billed=j["billedQB"], left=round(j["quoted"] - j["billedQB"]), hrs=j.get("hrs"),
                          margin=j.get("margin"), next=ev[0]["date"] if ev else "", last=j.get("lastBilling") or (ev[-1]["date"] if ev else "")))
    # 5. Outflows
    b = inp["burnWeekly"]
    for i in range(13):
        cout["burn"][i] += b["core"]; cout["disc"][i] += b["discretionary"]; cout["draws"][i] += b["draws"]
    for c in inp.get("cutsWeekly", []):
        for i in range(13):
            if weeks[i] >= D(c["from"]): cout["burn"][i] -= c["weekly"]
    for bl in inp["bills"]:
        add(cout, "ap", max(D(bl["due"]), today), bl["amount"])
    for s in inp.get("scheduledOut", []):
        add(cout, s.get("cat", "other"), D(s["date"]), s["amount"], s.get("note"))
    # 6. Roll forward
    bal = inp["openingCash"]; out = []; closes = []
    for i in range(13):
        ci = sum(cin[k][i] for k in cin); co = sum(cout[k][i] for k in cout)
        bal += ci - co; closes.append(round(bal))
        out.append(dict(start=str(weeks[i]), driver="; ".join(notes[i]),
                        **{"in": {k: round(cin[k][i]) for k in cin}, "out": {k: round(cout[k][i]) for k in cout}}))
    # 7. Upside line: expected service/T&M/parts work net of parts
    u = inp.get("upside")
    upside = None
    if u:
        add_in = [0.0] * 13; add_out = [0.0] * 13
        for i in range(1, 13):
            k = wk(weeks[i] + dt.timedelta(2 + u["lagDays"]))
            if k is not None: add_in[k] += u["serviceWeekly"]
        for i in range(u.get("partsFromWeek", 5), 13): add_out[i] += u["partsWeekly"]
        run_ = inp["openingCash"]; upside = []
        for i in range(13):
            run_ += (sum(cin[k][i] for k in cin) + add_in[i]) - (sum(cout[k][i] for k in cout) + add_out[i])
            upside.append(round(run_))
    apByWeek = [round(cout["ap"][i]) for i in range(5)]
    data = dict(inp["display"])
    data.update(asOf=inp["asOf"], weeks=out, upside=upside, jobs=table)
    data.setdefault("ap", {})["byWeek"] = apByWeek
    return data, closes

if __name__ == "__main__":
    inp = json.load(open(sys.argv[1]))
    data, closes = run(inp)
    json.dump(data, open(sys.argv[2], "w"))
    low = min(closes)
    print("Closing cash by week:", closes)
    print("Low:", low, "week of", data["weeks"][closes.index(low)]["start"])
