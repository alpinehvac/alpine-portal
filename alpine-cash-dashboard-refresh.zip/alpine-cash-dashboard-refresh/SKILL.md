---
name: alpine-cash-dashboard-refresh
description: "Refresh Alpine HVAC's Cash Position dashboard: pull today's QuickBooks (via Windsor) and BuildOps (via Chrome) data, rebuild the 13-week committed-only cash forecast, log actual cash, and save the result to the Alpine Portal. Use for the daily scheduled refresh, or whenever Jake, Mike or Clarissa asks to refresh, update or re-run the cash dashboard, cash forecast or 13-week cash."
---

# Alpine Cash Dashboard — Daily Refresh

Rebuilds the portal's **Cash Position** page from live data. Output: one JSON data file saved to the portal (Firestore `cash_dashboard/latest`, via the page's "Update data" box) plus a short change summary for Jake.

Files in this skill:
- `scripts/forecast.py` — the forecast engine. `python3 scripts/forecast.py inputs.json data.json`
- `inputs-2026-09-29.json` — the first inputs file; the reference for every field. Each run starts from the most recent `inputs-YYYY-MM-DD.json` in the working folder and saves a new one.

## Standing rules — never violate
1. **QuickBooks and BuildOps are read-only.** Never create, edit, send, approve, void or delete anything in either. Never enter a password, passkey or 2FA code; if asked to sign in, stop and tell Jake.
2. **The only write is saving the data file** in the portal's Cash Position "Update data" box. Nothing else in the portal is changed.
3. **QuickBooks is the source of truth** for cash, invoices, bills and billed-to-date. **BuildOps is the source of truth** for quotes (quoted value, cost, budgeted hours, PO/"Customer PO") and job status.
4. **Base forecast = committed money only:** open invoices, monthly contracts, parts estimates already created, and quoted jobs. No assumed new service/T&M work in the base. That lives only in the `upside` line.
5. Never guess a number. If something can't be found, keep the previous value, and add a ✕ line to `display.checks` saying what is stale.
6. Numbered lists in the summary to Jake.

## Step 1 — QuickBooks (Windsor connector `quickbooks`)
1. **Bank balances** (`accounts__fullyqualifiedname`, `accounts__currentbalance`). Use only the live accounts (they match RBC):
   1. Operating = `10000 RBC Chequing (4498)` + `10100 RBC Profit` (QuickBooks book balances). This is `openingCash`. `Income (4498)` and `Alpine Profit (2013)` are stale duplicates; ignore them.
   2. Earmarked = `RBC HST`, `RBC WSIB/Taxes`.
   3. Owner allocations = `RBC ML Profit`, `RBC JG Profit`, `Jake Donations`, `JG HoldCo`, `ML HoldCo`.
   4. Cards = the `RBC CC (name)` accounts. Loans and line of credit from the liability accounts.
   5. Ignore the stale duplicates (bracketed account numbers like `Alpine Profit (2013)`, `HST (3953)`, `Mike Profit (8259)`, `X - VISA (nnnn)`, `Cash (Gilmore)`, `Cash (Launder)`).
2. **Append today's actual:** `display.actuals.push({date: today, cash: openingCash})`.
3. **Open invoices** (`invoices__*`, balance > 0): doc, date, balance, customer, privatenote. Future-dated invoices count. Contract invoices (C-prefix, Finer Space / Blanchard on the 1st) are handled by `contracts`, so leave those out of `openInvoices`.
4. **Open bills** (`bills__duedate`, `bills__balance` > 0) → `bills` (due, amount).
5. **Estimates** (`estimates__*`, status not Closed): **an asterisk around the number means already sent; ignore those.** Unstarred estimates are recorded at cost: add each to `scheduledIn` at the second Wednesday of the month after the estimate date, amount = cost ÷ 0.65 × 1.13, lagDays 30.
6. **Billed-to-date per job:** sum 2026 invoices whose `privatenote` contains the job's PO number (e.g. `00742`). That is `billedQB`. If BuildOps shows more billed than QuickBooks, flag it in checks. It means invoices were created in BuildOps but never reached QuickBooks.
7. **History:** append last week's closing book balance and cash in/out (general ledger for the two operating accounts, excluding transfers between Alpine accounts) to `display.history`; keep the last 52 weeks.
8. **Mondays only:**
   1. Recompute customer days-to-pay: payments over the last 12 months, `payments__line` LinkedTxn → invoice date. This gives each customer's lagDays; the default is the company average.
   2. Recompute the 13-week collections list.
   3. Recompute the service run-rate: invoices over 13 weeks, less contracts, less invoices with a quoted-job PO. Recompute service parts the same way: supplier bills (and card purchases to Supplies & Materials) over 13 weeks whose memo PO is not a quoted-job PO (quoted-job POs = BuildOps jobs with Amount Quoted > 0). Set `upside.serviceWeekly` and `upside.partsWeekly` (both incl. HST).
   4. Update core burn from the general ledger over the trailing 13 weeks (field labour, office payroll, fixed overhead, vehicles, shop supplies, loans, other). When Jake reports a cost change (a position ended, a subscription cancelled), apply it to `burnWeekly` from its effective date right away instead of waiting for the 13-week average to catch up, and note it in `display.assumptions`. Exclude `Mike/Jake Building Materials` and `Non-Recoverable COGS` from expenses; they're owner draws.

## Step 2 — BuildOps (Claude in Chrome, https://live.buildops.com)
1. **Jobs list** (`/job/list`, 100 rows per page, 2 pages). The grid is virtualised, so collect rows by scrolling `.MuiDataGrid-window` with JavaScript and reading `.MuiDataGrid-cell[data-field]`. Fields: `customIdentifier, status, billingStatus, amountQuoted, totalBilledJobComputed, jobTypeName, customerName, customerProvidedPONumber, createdDate`. Go to page 2 with `button[aria-label="Next page"]`.
2. **Quotes list** (`/quote/list`): note any quote newly "Approved & Job Added" since the last run.
3. **For each open quoted job that is new or changed**, open `/job/view/<number>` and read the CUSTOMER PROVIDED P O NUMBER, QUOTE SUBTOTAL, COST AMOUNT, TOTAL BUDGETED HOURS and visit count.
4. **Job costing (Mondays, and for any job billed or newly approved):** on each open quoted job, open the **Job Costing** tab and read the `Labor` row (estimated cost, actual cost). Store these as `profitInputs.jobs[].labEst` / `labAct`. `costEst` = the job's COST AMOUNT; `sub` = QUOTE SUBTOTAL (pre-HST).
5. Close any tabs you opened.

## Step 2b — Profit inputs
1. `profitInputs.jobs[].matQB` = QuickBooks bills plus card purchases whose memo carries the job's PO, before HST (÷ 1.13). `billedQB` = QuickBooks invoices with that PO, including HST.
2. `start` / `end` = the job's working window (crew schedule; Jake's overrides win). Percent complete, earned, earned-not-billed and the 13-week projection are calculated by the engine.
3. **Fiscal year runs Oct 1 – Sep 30.** On the first Monday of each month, refresh `display.health.fy`: monthly QuickBooks P&L for the current fiscal year (and the full prior fiscal year until the new one has 3 months), with Mike/Jake Building Materials and Non-Recoverable COGS added back per month; label e.g. "FY2027 (Oct 2026 – Sep 2027)". Also replace `profitInputs.past` with the last 13 weeks: QuickBooks monthly P&L spread evenly by day, with Mike/Jake Building Materials and Non-Recoverable COGS removed. Update `pastQuarter`.
4. `contractsMonthly`, `serviceWeekly`, `servicePartsWeekly` (pre-HST) and `fixedWeekly` (core burn less loan principal, plus discretionary) come from the Monday recalculations.

5. **Completed jobs:** when a quoted job becomes Complete or Fully Invoiced in BuildOps, add it to `profitInputs.completed`: quoted subtotal, billed (QuickBooks by PO, pre-HST), estimated vs actual labour ($ and hours from Job Costing), estimated materials (cost amount minus labour) vs actual materials (QuickBooks by PO), and a one-line note on where the gain or loss came from. Keep the last 12 completed jobs.
6. **Job detail (Mondays and when a job closes):** for each open or completed job, store `profitInputs.jobDetail[<job name>]`: `labour` (per tech from the Job Costing tab: name, cost, hours at $70; the tab lists each entry twice, so halve when the total is double the Labor actual; any remainder goes on a 'Not attributed to a tech' line), `materials` (each QuickBooks bill or card purchase on the job's PO: vendor, date, amount pre-HST, memo with the PO number removed), `invoices` (QuickBooks invoices on the PO). Mark jobs whose scope is changing with `scopeChanging: true` and a `note`. Use QuickBooks only for non-labour actuals.
7. **Grouping:** jobs for the same customer and site that ran at the same time share costs (for example NPSC ERV and NPSC Dehum/Hum). Give them the same `group` name so they're measured as one.

## Step 3 — Update `inputs` and run the engine
1. **`jobs`:** one entry per open quoted job. `quoted` = BuildOps quote total (incl. HST); `billedQB` from Step 1.6; `margin` = (subtotal − cost) ÷ subtotal.
2. **Billing events for each job (thirds):** 1/3 at start, 1/3 at equipment delivery (about 2 weeks in), 1/3 at completion. Remove any third already in QuickBooks. Each event's lagDays = that customer's days-to-pay. Jake's overrides always win: for example, 21 Hunter's final third in mid-February, and materials two thirds Dec 31 / one third mid-February.
3. **`scheduledOut`:** card payments, CRA/WSIB remittances, the HST shortfall (HST owed minus the HST account balance, due at quarter-end + 1 month), and any one-offs Jake has confirmed.
4. **Display fields to refresh:**
   1. `accounts`, `ar` (total, future-dated, over-60, risk list, top list), `ap.total` and `topPOs`.
   2. `toBill`, `collections`, `checks`, `sources`, `levers`, `squeezeNote`.
   3. `scen`: re-run the four scenarios by copying the inputs and applying each lever or cut. Clarissa can see this page: label staffing scenarios generically ("Cost reductions"). Never name employees or show individual salaries.
5. **Timestamps:** set `display.updated.quickbooks` and `display.updated.buildops` to the ISO date-time each pull finished. Only set `display.updated.rbc` when Jake provides an RBC screenshot. The page flags any source older than 30 hours as stale.
6. **Run:** `python3 scripts/forecast.py inputs-<today>.json data-<today>.json`
7. **Checks (write each as a ✓/✕ line in `display.checks`):**
   1. QuickBooks operating book balance vs the latest RBC screenshot. Report the difference; uncleared items are normal, but a growing gap needs Clarissa.
   2. Open invoices total vs the A/R account.
   3. Open bills total vs the A/P account.
   4. Every BuildOps-vs-QuickBooks billing mismatch.
   5. How far last week's forecast closing cash was from actual.

## Step 4 — Save to the portal
1. In Chrome, open the Alpine Portal **Cash Position** page (Financials → Cash Position). It must already be signed in as Jake. If it shows the login page, stop and tell Jake.
2. Paste the full contents of `data-<today>.json` into the **Update data** box and click **Save data**. Confirm the page reloads with today's date.

## Step 5 — Summary to Jake (in the task output)
1. Operating cash today, and the change since yesterday.
2. The 13-week low (amount and week), and whether it's beyond the $140K line.
3. What changed:
   1. New approved jobs.
   2. Invoices paid or raised.
   3. New bills due in the next 3 weeks.
   4. Estimates starred.
4. Every ✕ check (mismatches, stale data).
5. One recommended action, if any.

## Step 6 — Business context check (every run; questions on Mondays)
Keep a running log in `inputs.context`: a list of `{date, change, effective, impact, applied}` entries. Read it at the start of every run and apply every entry to the forecast (burn, scheduled outflows, job timing, billing terms).

1. **Never stop and wait for answers.** Scheduled runs are unattended. Finish the refresh on current assumptions, then put the questions at the end of the summary.
2. **Monday standing questions:** ask these in a short numbered list, every Monday:
   1. Any staffing changes coming? Hires, departures, raises, or changed hours, with effective dates.
   2. Any new or cancelled recurring costs? Subscriptions, leases, insurance, vehicles, rent.
   3. Any large one-time payments or receipts in the next 13 weeks? Equipment, tax instalments, owner draws, loans, deposits.
   4. Any job changes? Approvals, cancellations, scope changes or change orders, revised start or finish dates, or billing terms that differ from thirds.
3. **Ask about anything the data shows that the log doesn't explain** (any weekday). Ask only when one of these appears:
   1. Weekly payroll moves more than 10% from the 13-week average.
   2. A new vendor or bill over $5,000 appears, or a new recurring charge.
   3. A quoted job over $20,000 is approved, cancelled or changes value in BuildOps.
   4. A customer invoice passes 60 days, or a customer pays much later than usual.
   5. A bank balance moves more than $25,000 in a day with no matching invoice or bill.
   6. Owner draws or dividends differ from the usual pattern.
4. **When Jake answers** (in this chat or a later one): add an entry to `inputs.context`, apply it from the effective date, re-run the forecast and save to the portal. Note each applied change in `display.assumptions` (for example: "From Oct 26: two field positions removed, −$4,022/week").
5. **Keep the summary short:** at most 4 questions per run, most important first. Skip any standing question Jake answered in the last 7 days unless something new triggered it.
