---
name: alpine-cash-dashboard-refresh
description: "Refresh Alpine HVAC's Cash Position dashboard: pull today's QuickBooks (via Windsor) and BuildOps (via Chrome) data, rebuild the 13-week committed-only cash forecast, log actual cash, and save the result to the Alpine Portal. Use for the daily scheduled refresh, or whenever Jake, Mike or Clarissa asks to refresh, update or re-run the cash dashboard, cash forecast or 13-week cash."
---

# Alpine Cash Dashboard — Daily Refresh

Rebuilds the portal's **Cash Position** page from live data. Output: one JSON data file saved to the portal (Firestore `cash_dashboard/latest`, via the page's "Update data" box) plus a short change summary for Jake.

Files in this skill:
- `scripts/forecast.py` — the forecast engine. `python3 scripts/forecast.py inputs.json data.json`
- `inputs-2026-09-29.json` — the first inputs file; the reference for every field. Each run starts from the most recent `inputs-YYYY-MM-DD.json` in the working folder and saves a new one.

## Standing rules — never violate
1. **QuickBooks and BuildOps are read-only.** Never create, edit, send, approve, void or delete anything in either. Never enter a password, passkey or 2FA code; if asked to sign in, stop and tell Jake.
2. **The only write is saving the data file** in the portal's Cash Position "Update data" box. Nothing else in the portal is changed.
3. **QuickBooks is the source of truth** for cash, invoices, bills and billed-to-date. **BuildOps is the source of truth** for quotes (quoted value, cost, budgeted hours, PO/"Customer PO") and job status.
4. **Base forecast = committed money only:** open invoices, monthly contracts, parts estimates already created, and quoted jobs. No assumed new service/T&M work in the base. That lives only in the `upside` line.
5. Never guess a number. If something can't be found, keep the previous value, and add a ✕ line to `display.checks` saying what is stale.
6. Numbered lists in the summary to Jake.

## Step 1 — QuickBooks (Windsor connector `quickbooks`)
1. **Bank balances** (`accounts__fullyqualifiedname`, `accounts__currentbalance`). Use only the live accounts (they match RBC):
   1. Operating = `Income (4498)` + `RBC Profit`. This is `openingCash`.
   2. Earmarked = `RBC HST`, `RBC WSIB/Taxes`.
   3. Owner allocations = `RBC ML Profit`, `RBC JG Profit`, `Jake Donations`, `JG HoldCo`, `ML HoldCo`.
   4. Cards = the `RBC CC (name)` accounts. Loans and line of credit from the liability accounts.
   5. Ignore the stale duplicates (bracketed account numbers like `Alpine Profit (2013)`, `HST (3953)`, `Mike Profit (8259)`, `X - VISA (nnnn)`, `Cash (Gilmore)`, `Cash (Launder)`).
2. **Append today's actual:** `display.actuals.push({date: today, cash: openingCash})`.
3. **Open invoices** (`invoices__*`, balance > 0): doc, date, balance, customer, privatenote. Future-dated invoices count. Contract invoices (C-prefix, Finer Space / Blanchard on the 1st) are handled by `contracts`, so leave those out of `openInvoices`.
4. **Open bills** (`bills__duedate`, `bills__balance` > 0) → `bills` (due, amount).
5. **Estimates** (`estimates__*`, status not Closed): **an asterisk around the number means already sent; ignore those.** Unstarred estimates are recorded at cost: add each to `scheduledIn` at the second Wednesday of the month after the estimate date, amount = cost ÷ 0.65 × 1.13, lagDays 30.
6. **Billed-to-date per job:** sum 2026 invoices whose `privatenote` contains the job's PO number (e.g. `00742`). That is `billedQB`. If BuildOps shows more billed than QuickBooks, flag it in checks. It means invoices were created in BuildOps but never reached QuickBooks.
7. **Mondays only:**
   1. Recompute customer days-to-pay: payments over the last 12 months, `payments__line` LinkedTxn → invoice date. This gives each customer's lagDays; the default is the company average.
   2. Recompute the 13-week collections list.
   3. Recompute the service run-rate: invoices over 13 weeks, less contracts, less invoices with a quoted-job PO.
   4. Update core burn from the general ledger (Jul–Sep method: field labour, office payroll, fixed overhead, vehicles, shop supplies, loans, other). Exclude `Mike/Jake Building Materials` and `Non-Recoverable COGS` from expenses; they're owner draws.

## Step 2 — BuildOps (Claude in Chrome, https://live.buildops.com)
1. **Jobs list** (`/job/list`, 100 rows per page, 2 pages). The grid is virtualised, so collect rows by scrolling `.MuiDataGrid-window` with JavaScript and reading `.MuiDataGrid-cell[data-field]`. Fields: `customIdentifier, status, billingStatus, amountQuoted, totalBilledJobComputed, jobTypeName, customerName, customerProvidedPONumber, createdDate`. Go to page 2 with `button[aria-label="Next page"]`.
2. **Quotes list** (`/quote/list`): note any quote newly "Approved & Job Added" since the last run.
3. **For each open quoted job that is new or changed**, open `/job/view/<number>` and read the CUSTOMER PROVIDED P O NUMBER, QUOTE SUBTOTAL, COST AMOUNT, TOTAL BUDGETED HOURS and visit count.
4. Close any tabs you opened.

## Step 3 — Update `inputs` and run the engine
1. **`jobs`:** one entry per open quoted job. `quoted` = BuildOps quote total (incl. HST); `billedQB` from Step 1.6; `margin` = (subtotal − cost) ÷ subtotal.
2. **Billing events for each job (thirds):** 1/3 at start, 1/3 at equipment delivery (about 2 weeks in), 1/3 at completion. Remove any third already in QuickBooks. Each event's lagDays = that customer's days-to-pay. Jake's overrides always win: for example, 21 Hunter's final third in mid-February, and materials two thirds Dec 31 / one third mid-February.
3. **`scheduledOut`:** card payments, CRA/WSIB remittances, the HST shortfall (HST owed minus the HST account balance, due at quarter-end + 1 month), and any one-offs Jake has confirmed.
4. **Display fields to refresh:**
   1. `accounts`, `ar` (total, future-dated, over-60, risk list, top list), `ap.total` and `topPOs`.
   2. `toBill`, `collections`, `checks`, `sources`, `levers`, `squeezeNote`.
   3. `scen`: re-run the four scenarios by copying the inputs and applying each lever or cut.
5. **Run:** `python3 scripts/forecast.py inputs-<today>.json data-<today>.json`
6. **Checks (write each as a ✓/✕ line in `display.checks`):**
   1. Operating cash matches the previous RBC screenshot, within timing.
   2. Open invoices total vs the A/R account.
   3. Open bills total vs the A/P account.
   4. Every BuildOps-vs-QuickBooks billing mismatch.
   5. How far last week's forecast closing cash was from actual.

## Step 4 — Save to the portal
1. In Chrome, open the Alpine Portal **Cash Position** page (Financials → Cash Position). It must already be signed in as Jake. If it shows the login page, stop and tell Jake.
2. Paste the full contents of `data-<today>.json` into the **Update data** box and click **Save data**. Confirm the page reloads with today's date.

## Step 5 — Summary to Jake (in the task output)
1. Operating cash today, and the change since yesterday.
2. The 13-week low (amount and week), and whether it's beyond the $140K line.
3. What changed:
   1. New approved jobs.
   2. Invoices paid or raised.
   3. New bills due in the next 3 weeks.
   4. Estimates starred.
4. Every ✕ check (mismatches, stale data).
5. One recommended action, if any.
